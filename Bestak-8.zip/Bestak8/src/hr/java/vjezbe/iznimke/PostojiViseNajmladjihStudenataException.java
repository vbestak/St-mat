package hr.java.vjezbe.iznimke;

/**
 * Predstavlja iznimku koja se baca u slucaju vise najmladjih studenata.
 * 
 * @author ValentinoBestak
 *
 */
public class PostojiViseNajmladjihStudenataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1324053465120359404L;
	
	/**
	 *Inicijalizira iznimku.
	 * 
	 */
	public PostojiViseNajmladjihStudenataException() { 
		super(); 
		}
	
	/**
	 * Inicijalizira iznimku s porukom.
	 * 
	 * @param poruka
	 */
	public PostojiViseNajmladjihStudenataException(String poruka) { 
		super(poruka); 
		}
	
	/**
	 * Inicijalizira iznimku s uzrokom.
	 * 
	 * @param uzrok
	 */
	public PostojiViseNajmladjihStudenataException(Throwable uzrok) { 
		super(uzrok); 
		}
	
	/**
	 * Inicijalizira iznimku s porukom i uzrokom.
	 * 
	 * @param poruka
	 * @param uzrok
	 */
	public PostojiViseNajmladjihStudenataException(String poruka, Throwable uzrok) {
		super(poruka, uzrok); 
	}
	
	
}
