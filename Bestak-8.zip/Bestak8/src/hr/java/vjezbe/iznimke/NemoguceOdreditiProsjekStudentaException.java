package hr.java.vjezbe.iznimke;

/**
 * Predstavlja iznimku koja se desi u slucaju jedince u jednom od ispita kod racunanja prosjeka.
 * 
 * @author ValentinoBestak
 *
 */
public class NemoguceOdreditiProsjekStudentaException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2354675407061208204L;

	/**
	 * Inicijalizira iznimku.
	 * 
	 */
	public NemoguceOdreditiProsjekStudentaException() { 
		super(); 
		}
	
	/**
	 * Inicijalizira iznimku s porukom.
	 * 
	 * @param poruka
	 */
	public NemoguceOdreditiProsjekStudentaException(String poruka) { 
		super(poruka); 
		}
	
	/**
	 * Inicijalizira iznimku s uzrokom.
	 * 
	 * @param uzrok
	 */
	public NemoguceOdreditiProsjekStudentaException(Throwable uzrok) { 
		super(uzrok); 
		}
	
	/**
	 * Inicijalizira iznimku s porukom i uzrokom.
	 * 
	 * @param poruka
	 * @param uzrok
	 */
	public NemoguceOdreditiProsjekStudentaException(String poruka, Throwable uzrok) {
		super(poruka, uzrok); 
	}
}
