package hr.java.vjezbe;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import hr.java.vjezbe.entitet.Profesor;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ProfesorController{
	List<Profesor> profesori = new ArrayList<>();
	List<Profesor> filtriraniProfesori = new ArrayList<>();
	ObservableList<Profesor> list = FXCollections.observableArrayList();
	
	@FXML TextField sifraTextField;
	@FXML TextField prezimeTextField;
	@FXML TextField imeTextField;
	@FXML TextField titulaTextField;
	@FXML TableView<Profesor> table;
	@FXML TableColumn<Profesor, String> sifraColumn;
	@FXML TableColumn<Profesor, String> prezimeColumn;
	@FXML TableColumn<Profesor, String> imeColumn;
	@FXML TableColumn<Profesor, String> titulaColumn;
	@FXML Button pretragaButton;
	
	@FXML
	private void initialize() {
		profesori = GlavnaDatoteke.dohvatiProfesore();
		sifraColumn.setCellValueFactory(new PropertyValueFactory<>("sifra"));
		prezimeColumn.setCellValueFactory(new PropertyValueFactory<>("prezime"));
		imeColumn.setCellValueFactory(new PropertyValueFactory<>("ime"));
		titulaColumn.setCellValueFactory(new PropertyValueFactory<>("titula"));
		list.setAll(profesori);
		table.setItems(list);

	}
	
	@FXML
	private void pretragaButtonAction() {
		filtriraniProfesori.clear();
		filtriraniProfesori.addAll(profesori);
		
		if(sifraTextField.getText().length()>0) {
			filtriraniProfesori=filtriraniProfesori.stream()
					.filter( a -> a.getSifra().toLowerCase().contains(sifraTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(prezimeTextField.getText().length()>0) {
				filtriraniProfesori= filtriraniProfesori.stream()
						.filter( a -> a.getPrezime().toLowerCase().contains(prezimeTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(imeTextField.getText().length()>0){
				filtriraniProfesori= filtriraniProfesori.stream()
						.filter( a ->a.getIme().toLowerCase().contains(imeTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(titulaTextField.getText().length()>0) {
				filtriraniProfesori= filtriraniProfesori.stream()
						.filter( a -> a.getTitula().toLowerCase().contains(titulaTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		list.setAll(filtriraniProfesori);
		System.out.println("Gumb kliknut");
		
	}
	
}
