package hr.java.vjezbe;

import java.util.List;
import java.util.OptionalLong;

import hr.java.vjezbe.entitet.Predmet;
import hr.java.vjezbe.entitet.Profesor;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class PredmetUnosController {
	List<Predmet> predmeti;
	ObservableList<Profesor> list;

	@FXML TextField sifraTextField;
	@FXML TextField nazivTextField;
	@FXML TextField ectsTextField;
	@FXML ComboBox<Profesor> nositeljComboBox;
	
	
	@FXML
	private void initialize() {
		predmeti = GlavnaDatoteke.dohvatiPredmete();
		list= FXCollections.observableArrayList();
		list.setAll(GlavnaDatoteke.dohvatiProfesore());
		
		nositeljComboBox.setItems(list);
	}
	
	@FXML
	private void unesiButtonAction() {
		boolean flag =true;
		String error= new String();
		predmeti = GlavnaDatoteke.dohvatiPredmete();
		
		if(sifraTextField.getText().isEmpty()) {
			flag=false;
			error = error + " sifra";
		}
		
		if(nazivTextField.getText().isEmpty()) {
			flag=false;
			error = error + " naziv";
		}
		
		if(ectsTextField.getText().isEmpty()) {
			flag=false;
			error = error + " ects";
		}
		
		if(nositeljComboBox.getValue() == null) {
			flag=false;
			error = error + " nositelj";
		}
		
		if(flag) {
			OptionalLong id= predmeti.stream() .mapToLong(predmet -> predmet.getId()).max(); 
			ectsTextField.getText();
			GlavnaDatoteke.unosPredmeta(new Predmet(id.getAsLong()+1, sifraTextField.getText(), nazivTextField.getText(), Integer.parseInt(ectsTextField.getText()), nositeljComboBox.getValue()));

		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warrning");
			alert.setHeaderText("Greška prilikom unosa predmeta!");
			alert.setContentText("Niste unijeli:" + error);

			alert.showAndWait();
		}
	}
	
}
