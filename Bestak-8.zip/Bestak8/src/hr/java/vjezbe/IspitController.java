package hr.java.vjezbe;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import hr.java.vjezbe.entitet.Ispit;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

public class IspitController {

	List<Ispit> ispiti = new ArrayList<>();
	List<Ispit> filtriraniIspiti = new ArrayList<>();
	ObservableList<Ispit> list = FXCollections.observableArrayList();
	
	@FXML TextField nazivTextField;
	@FXML TextField studentTextField;
	@FXML TextField ocjenaTextField;
	@FXML DatePicker datumField;
	@FXML TableView<Ispit> table;
	@FXML TableColumn<Ispit, String> nazivColumn;
	@FXML TableColumn<Ispit, String> prezimeColumn;
	@FXML TableColumn<Ispit, String> imeColumn;
	@FXML TableColumn<Ispit, String> ocjenaColumn;
	@FXML TableColumn<Ispit, String> datumColumn;

	@FXML Button pretragaButton;
	
	@FXML
	private void initialize() {
		
		ispiti = GlavnaDatoteke.dohvatiIspite();
		nazivColumn.setCellValueFactory(new PropertyValueFactory<>("naziv"));
		prezimeColumn.setCellValueFactory(new PropertyValueFactory<>("prezime"));
		imeColumn.setCellValueFactory(new PropertyValueFactory<>("ime"));
		ocjenaColumn.setCellValueFactory(new PropertyValueFactory<>("ocjena"));
		datumColumn.setCellValueFactory(new PropertyValueFactory<>("datumIVrijeme"));
		
		list.setAll(ispiti);
		table.setItems(list);
		
		
		datumColumn.setCellValueFactory( 
				new Callback<TableColumn.CellDataFeatures<Ispit, String>,
				ObservableValue<String>>() { 
					@Override    
					public ObservableValue<String> call(
							TableColumn.CellDataFeatures<Ispit, String> ispit) {
						SimpleStringProperty property = new  SimpleStringProperty();
						DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("HH:mm, dd.MM.yyyy."); 
						property.setValue( ispit.getValue().getDatumIVrijeme().format(formatter));   
						return property;   
						} 
				}
		);
	}
	
	@FXML
	private void pretragaButtonAction() {
		filtriraniIspiti.clear();
		filtriraniIspiti.addAll(ispiti);
		
		if(nazivTextField.getText().length()>0) {
			filtriraniIspiti=filtriraniIspiti.stream()
					.filter( a -> a.getNaziv().toLowerCase().contains(nazivTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(studentTextField.getText().length()>0) {
			String[] student= studentTextField.getText().split(" ");
			
			if(student.length > 1)
				filtriraniIspiti= filtriraniIspiti.stream()
				.filter( a -> a.getPrezime().toLowerCase().contains(student[0].toLowerCase())
				|| a.getPrezime().toLowerCase().contains(student[1].toLowerCase())
				|| a.getIme().toLowerCase().contains(student[0].toLowerCase())
				|| a.getIme().toLowerCase().contains(student[1].toLowerCase()))
				.collect(Collectors.toList());
			
			else	
				filtriraniIspiti= filtriraniIspiti.stream()
						.filter( a -> 
						a.getPrezime().toLowerCase().contains(studentTextField.getText().toLowerCase())
						|| a.getIme().toLowerCase().contains(studentTextField.getText().toLowerCase()))
						.collect(Collectors.toList());
		}
		
		if(ocjenaTextField.getText().length()>0) {
			filtriraniIspiti= filtriraniIspiti.stream()
						.filter( a -> a.getOcjena() == Integer.parseInt(ocjenaTextField.getText())).collect(Collectors.toList());
		}
		
		
		
		if(datumField.getValue() != null) {
			filtriraniIspiti= filtriraniIspiti.stream()
					.filter( a -> a.getDatumIVrijeme().toLocalDate().isEqual( (datumField.getValue()))).collect(Collectors.toList());
	
		}
		
		list.setAll(filtriraniIspiti);
		System.out.println("Gumb kliknut");
		
	}
}
