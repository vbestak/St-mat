package hr.java.vjezbe;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalLong;

import hr.java.vjezbe.entitet.Student;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class StudentUnosController {
	private List<Student> studenti;
	
	@FXML TextField jmbagTextField;
	@FXML TextField prezimeTextField;
	@FXML TextField imeTextField;
	@FXML DatePicker datumTextField;
	
	@FXML
	private void initialize() {
		studenti= new ArrayList<>();
		studenti.addAll(GlavnaDatoteke.dohvatiStudente());
	}
	
	@FXML
	private void unesiButtonAction() {
		boolean flag =true;
		String error= new String();
		studenti = GlavnaDatoteke.dohvatiStudente();
		
		if(jmbagTextField.getText().isEmpty()) {
			flag=false;
			error = error + " jmbag";
		}
		
		if(prezimeTextField.getText().isEmpty()) {
			flag=false;
			error = error + " prezime";
		}
		
		if(imeTextField.getText().isEmpty()) {
			flag=false;
			error = error + " ime";
		}
		
		if(datumTextField.getValue() == null) {
			flag=false;
			error = error + " datum";
		}
		
		if(flag) {
			OptionalLong id= studenti.stream() .mapToLong(student -> student.getId()).max(); 
			
			GlavnaDatoteke.unosStudenta(new Student( id.getAsLong()+1, imeTextField.getText(), prezimeTextField.getText(), jmbagTextField.getText(), datumTextField.getValue()));

		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warrning");
			alert.setHeaderText("Greška prilikom unosa studenta!");
			alert.setContentText("Niste unijeli:" + error);

			alert.showAndWait();
		}
	}
}
