package hr.java.vjezbe;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import hr.java.vjezbe.entitet.Predmet;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class PredmetController{

	List<Predmet> predmeti = new ArrayList<>();
	List<Predmet> filtriraniPredmeti = new ArrayList<>();
	ObservableList<Predmet> list = FXCollections.observableArrayList();
	
	@FXML TextField sifraTextField;
	@FXML TextField nazivTextField;
	@FXML TextField ectsTextField;
	@FXML TextField nositeljTextField;
	@FXML TableView<Predmet> table;
	@FXML TableColumn<Predmet, String> sifraColumn;
	@FXML TableColumn<Predmet, String> nazivColumn;
	@FXML TableColumn<Predmet, String> ectsColumn;
	@FXML TableColumn<Predmet, String> prezimeColumn;
	@FXML TableColumn<Predmet, String> imeColumn;
	@FXML Button pretragaButton;
	
	@FXML
	private void initialize() {
		predmeti = GlavnaDatoteke.dohvatiPredmete();
		sifraColumn.setCellValueFactory(new PropertyValueFactory<>("sifra"));
		nazivColumn.setCellValueFactory(new PropertyValueFactory<>("naziv"));
		ectsColumn.setCellValueFactory(new PropertyValueFactory<>("brojEctsBodova"));
		prezimeColumn.setCellValueFactory(new PropertyValueFactory<>("prezime"));
		imeColumn.setCellValueFactory(new PropertyValueFactory<>("ime"));
		list.setAll(predmeti);
		table.setItems(list);

	}
	
	@FXML
	private void pretragaButtonAction() {
		filtriraniPredmeti.clear();
		filtriraniPredmeti.addAll(predmeti);
		
		if(sifraTextField.getText().length()>0) {
			filtriraniPredmeti=filtriraniPredmeti.stream()
					.filter( a -> a.getSifra().toLowerCase().contains(sifraTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(nositeljTextField.getText().length()>0) {
			String[] profesor = nositeljTextField.getText().split(" ");
			
			if(profesor.length>1)	
				filtriraniPredmeti= filtriraniPredmeti.stream()
						.filter( a -> 
						a.getNositelj().getPrezime().toLowerCase().contains(profesor[0].toLowerCase())
						|| a.getNositelj().getPrezime().toLowerCase().contains(profesor[1].toLowerCase())
						|| a.getNositelj().getIme().toLowerCase().contains(profesor[1].toLowerCase())
						|| a.getNositelj().getIme().toLowerCase().contains(profesor[1].toLowerCase()))
						.collect(Collectors.toList());
			else
				filtriraniPredmeti= filtriraniPredmeti.stream()
						.filter( a -> 
						a.getNositelj().getPrezime().toLowerCase().contains(nositeljTextField.getText().toLowerCase())
						|| a.getNositelj().getIme().toLowerCase().contains(nositeljTextField.getText().toLowerCase()))
						.collect(Collectors.toList());
		}
		
		if(ectsTextField.getText().length()>0) {
			filtriraniPredmeti= filtriraniPredmeti.stream()
						.filter( a -> a.getBrojEctsBodova() == Integer.parseInt(ectsTextField.getText())).collect(Collectors.toList());
		}
		
		
		
		if(nazivTextField.getText().length()>0) {
			filtriraniPredmeti= filtriraniPredmeti.stream()
						.filter( a -> a.getNaziv().toLowerCase().contains(nazivTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		list.setAll(filtriraniPredmeti);
		System.out.println("Gumb kliknut");
		
	}
	
	
}
