package hr.java.vjezbe;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalLong;

import hr.java.vjezbe.entitet.Profesor;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

public class ProfesorUnosController {
	List<Profesor> profesori;
	
	@FXML TextField sifraTextField;
	@FXML TextField prezimeTextField;
	@FXML TextField imeTextField;
	@FXML TextField titulaTextField;
	
	
	@FXML
	private void initialize() {
		profesori= new ArrayList<>();
		profesori.addAll(GlavnaDatoteke.dohvatiProfesore());

	}
	
	@FXML
	private void unesiButtonAction() {
		boolean flag =true;
		String error= new String();
		
		 
		
		if(sifraTextField.getText().isEmpty()) {
			flag=false;
			error = error + " sifra";
		}
		
		if(prezimeTextField.getText().isEmpty()) {
			flag=false;
			error = error + " prezime";
		}
		
		if(imeTextField.getText().isEmpty()) {
			flag=false;
			error = error + " ime";
		}
		
		if(titulaTextField.getText().isEmpty()) {
			flag=false;
			error = error + " titula";
		}
		
		if(flag) {
			OptionalLong id= profesori.stream() .mapToLong(profesor -> profesor.getId()).max(); 
			GlavnaDatoteke.unosProfesora(new Profesor( id.getAsLong()+1, sifraTextField.getText(), imeTextField.getText(), prezimeTextField.getText(), titulaTextField.getText()));
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warrning");
			alert.setHeaderText("Greška prilikom unosa profesora!");
			alert.setContentText("Niste unijeli:" + error);

			alert.showAndWait();
		}
		
	}
	
}
