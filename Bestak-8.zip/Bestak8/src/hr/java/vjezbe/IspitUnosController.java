package hr.java.vjezbe;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.OptionalLong;

import hr.java.vjezbe.entitet.Ispit;
import hr.java.vjezbe.entitet.Predmet;
import hr.java.vjezbe.entitet.Student;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class IspitUnosController {
	List<Ispit> ispiti;
	List<Predmet> predmeti;
	ObservableList<Predmet> predmetList;
	ObservableList<Student> studentList;
	
	@FXML ComboBox<Predmet> nazivComboBox;
	@FXML ComboBox<Student> studentComboBox;
	@FXML TextField ocjenaTextField;
	@FXML DatePicker datumField;
	@FXML TextField vrijemeTextField;
	
	@FXML
	private void initialize() {
		
		ispiti = GlavnaDatoteke.dohvatiIspite();
		predmetList= FXCollections.observableArrayList();
		studentList= FXCollections.observableArrayList();
		
		studentList.setAll(GlavnaDatoteke.dohvatiStudente());
		predmetList.setAll(GlavnaDatoteke.dohvatiPredmete());
		
		nazivComboBox.setItems(predmetList);
		studentComboBox.setItems(studentList);
	}
	
	
	
	@FXML
	private void unesiButtonAction() {
		boolean flag =true;
		String error= new String();
		predmeti = GlavnaDatoteke.dohvatiPredmete();
		
		if(nazivComboBox.getValue() == null) {
			flag=false;
			error = error + " naziv";
		}
		
		if(studentComboBox.getValue() == null) {
			flag=false;
			error = error + " student";
		}
		
		if(ocjenaTextField.getText().isEmpty()) {
			flag=false;
			error = error + " ocjena";
		}
		
		if(datumField.getValue() == null) {
			flag=false;
			error = error + " datum";
		}
		
		if(vrijemeTextField.getText().isEmpty()) {
			flag=false;
			error = error + " vrijeme";
		}
		
		if(flag) {
			OptionalLong id= ispiti.stream() .mapToLong(ispit -> ispit.getId()).max(); 
			LocalTime localTime= LocalTime.parse(vrijemeTextField.getCharacters(),DateTimeFormatter.ofPattern("HH:mm"));
			LocalDateTime datum= LocalDateTime.of(datumField.getValue(), localTime);
			
			GlavnaDatoteke.unosIspita(new Ispit(id.getAsLong()+1, nazivComboBox.getValue(), studentComboBox.getValue(), Integer.parseInt(ocjenaTextField.getText()), datum));

		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Warrning");
			alert.setHeaderText("Greška prilikom unosa ispita!");
			alert.setContentText("Niste unijeli:" + error);

			alert.showAndWait();
		}
	}
}
