package hr.java.vjezbe.sortiranje;

import java.util.Comparator;

import hr.java.vjezbe.entitet.ObrazovnaUstanova;

public class ObrazovnaUstanovaSorter implements Comparator<ObrazovnaUstanova> {

	@Override
	public int compare(ObrazovnaUstanova o1, ObrazovnaUstanova o2) {
		if( o2.getStudent().size() > o1.getStudent().size()) {
			return 1;
			
		}else if( o2.getStudent().size() < o1.getStudent().size()) {
			return -1;
			
		}else if ( o2.getStudent().size() == o1.getStudent().size()) {
			if( o2.getNazivUstanove().compareTo(o1.getNazivUstanove()) <0 ) {
				return 1;
				
			}else if( o2.getNazivUstanove().compareTo(o1.getNazivUstanove()) >0 ) {
				return -1;
					
			}else {
				return 0;
			}
		}
		
		return 0;
	}
	}

