package hr.java.vjezbe.sortiranje;
import hr.java.vjezbe.entitet.Student;
import java.util.Comparator;

/**
 * Sorter za studente. Prvo sortira po prezimenu, a zatim po imenu studenata.
 * 
 * @author ValentinoBestak
 *
 */
public class StudentSorter implements Comparator<Student> {

	/**
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(Student o1, Student o2) {
		if( (o2.getPrezime().compareTo(o1.getPrezime())) < 0) {
			return 1;
			
		}else if( (o2.getPrezime().compareTo(o1.getPrezime())) > 0) {
			return -1;
			
		}else if ( (o2.getPrezime().compareTo(o1.getPrezime())) == 0) {
			if( (o2.getIme().compareTo(o1.getIme())) < 0) {
				return 1;
				
			}else if( (o2.getPrezime().compareTo(o1.getPrezime())) > 0) {
				return -1;
					
			}else {
				return 0;
			}
		}
		
		return 0;
	}

}
