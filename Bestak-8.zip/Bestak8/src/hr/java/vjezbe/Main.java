package hr.java.vjezbe;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


public class Main extends Application {
	
	//private static Stage stage;
	private static BorderPane borderPane;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("Izbornik.fxml"));
			Scene scene = new Scene(root,550,550);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			//stage = primaryStage;
			borderPane=root;
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	public static void setMainPage(BorderPane root) {  
		/*Scene scene = new Scene(root,550,550);  
		stage.setScene(scene);   
		stage.show();  */
		borderPane.setCenter(root.getCenter());
		borderPane.setBottom(root.getBottom());
	}

}
