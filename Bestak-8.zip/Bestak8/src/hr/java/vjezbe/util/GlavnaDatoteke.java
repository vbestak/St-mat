package hr.java.vjezbe.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hr.java.vjezbe.entitet.FakultetRacunarstva;
import hr.java.vjezbe.entitet.Ispit;
import hr.java.vjezbe.entitet.ObrazovnaUstanova;
import hr.java.vjezbe.entitet.Predmet;
import hr.java.vjezbe.entitet.Profesor;
import hr.java.vjezbe.entitet.Student;
import hr.java.vjezbe.entitet.VeleucilisteJave;


/**
 * Glavna klasa za izvrsavanje programa. (Sadrzi main metodu).
 * 
 * @author ValentinoBestak
 *
 */
public class GlavnaDatoteke {
	
	/**
	 * Sadrzi putanje datoteka.
	 * 
	 * @author ValentinoBestak
	 *
	 */
	public enum Datoteke{
		Profesori("dat//profesori.txt"),
		Studenti("dat//studenti.txt"),
		Predmeti("dat//predmeti.txt"),
		Ispiti("dat//ispiti.txt"),
		Obrazovne_Ustanove("dat//obrazovne_ustanove.txt"),
		Ocjene_Zavrsni("dat//ocjeneZavrsni.txt"),
		Dat_Datoteka("dat//obrazovne-ustanove.dat");
		
		private String dat;
		
		private Datoteke(String dat) {
			this.dat = dat;
		}
		
		public String getDat() {
			return this.dat;
		}
		
	}
	
	/**
	 * Sadrzi broj obrazovne ustanove.
	 * 
	 * @author ValentinoBestak
	 *
	 */
	public enum Ustanova{
		FakultetRacunarstva(1),
		VeleucilisteJave(2),;
		
		int id;
		
		private Ustanova(int id) {
			this.id=id;
		}
		
		public int getUstanova() {
			return this.id;
		}
	}
	
	private final static String DATUM = "dd.MM.yyyy.";
	private final static String DATUM_ISPIT = "dd.MM.yyyy.'T'HH:mm";

	
	private static Logger logger = LoggerFactory.getLogger(GlavnaDatoteke.class);
	
	///UNOS ISPITA
			public static void unosIspita(Ispit ispit) {
				
				try (BufferedWriter br = Files.newBufferedWriter(Paths.get(Datoteke.Ispiti.getDat()), StandardOpenOption.APPEND)) {
					
					br.newLine();
					br.write(String.valueOf(ispit.getId()));
					br.newLine();
					br.write(String.valueOf(ispit.getStudent().getId()));
					br.newLine();
					br.write(String.valueOf(ispit.getPredmet().getId()));
					br.newLine();
					br.write(String.valueOf(ispit.getOcjena()));
					br.newLine();
					br.write(ispit.getDatumIVrijeme().format(DateTimeFormatter.ofPattern(DATUM_ISPIT)));
										
					} catch (IOException e) {
						logger.info("Nije moguce ucitati datoteku.");
						System.out.println("Nije moguce ucitati datoteku ispita ERROR!");
						System.exit(1);
					}
				
			}
	
	///UNOS PREDMETA
			public static void unosPredmeta(Predmet predmet) {
				
				try (BufferedWriter br = Files.newBufferedWriter(Paths.get(Datoteke.Predmeti.getDat()), StandardOpenOption.APPEND)) {
					
					br.newLine();
					br.write(String.valueOf(predmet.getId()));
					br.newLine();
					br.write(predmet.getSifra());
					br.newLine();
					br.write(predmet.getNaziv());
					br.newLine();
					br.write(String.valueOf(predmet.getBrojEctsBodova()));
					br.newLine();
					br.write(String.valueOf(predmet.getNositelj().getId()));
					br.newLine();
					
					///UNOS STUDENATA PREDMETA
					boolean flag=true;
					for(Student student : predmet.getStudenti()) {
						
						if(flag) {
							flag=false;
							br.write(String.valueOf(student.getId()));
						}
						else {
							br.write(" ");
							br.write(String.valueOf(student.getId()));
						}
					}
					if(flag) {
						br.write(" ");
					}
										
					} catch (IOException e) {
						logger.info("Nije moguce ucitati datoteku.");
						System.out.println("Nije moguce ucitati datoteku premdeta ERROR!");
						System.exit(1);
					}
				
			}
			
	
	///UNOS STUDENTA
		public static void unosStudenta(Student student) {
			
			try (BufferedWriter br = Files.newBufferedWriter(Paths.get(Datoteke.Studenti.getDat()), StandardOpenOption.APPEND)) {
				
				br.newLine();
				br.write(String.valueOf(student.getId()));
				br.newLine();
				br.write(student.getIme());
				br.newLine();
				br.write(student.getPrezime());
				br.newLine();
				br.write(student.getJmbag());
				br.newLine();
				br.write(student.getDatumRodjenja().format(DateTimeFormatter.ofPattern(DATUM)));
									
				} catch (IOException e) {
					logger.info("Nije moguce ucitati datoteku.");
					System.out.println("Nije moguce ucitati datoteku studenata ERROR!");
					System.exit(1);
				}
			
		}
	
	///UNOS PROFESORA
	public static void unosProfesora(Profesor profesor) {
		
		try (BufferedWriter br = Files.newBufferedWriter(Paths.get(Datoteke.Profesori.getDat()), StandardOpenOption.APPEND)) {
			
			br.newLine();
			br.write(String.valueOf(profesor.getId()));
			br.newLine();
			br.write(profesor.getSifra());
			br.newLine();
			br.write(profesor.getIme());
			br.newLine();
			br.write(profesor.getPrezime());
			br.newLine();
			br.write(profesor.getTitula());
								
			} catch (IOException e) {
				logger.info("Nije moguce ucitati datoteku.");
				System.out.println("Nije moguce ucitati datoteku profesora ERROR!");
				System.exit(1);
			}
		
	}
	
	
	///STAVLJANJE POLJA U LISTU
	/**
	 * Pretvaranje stringa u listu integera.
	 * 
	 * @param Polje stringa
	 * @return lista integera koji se sastoji od polja stringa
	 */
	public static List<Integer> splitString(String[] line){
		List<Integer> list = new ArrayList<>();
		
		for(String a : line) {
			list.add(Integer.parseInt(a));
		}
		
		return list;
	}
	
	
	///CITANJE OBRAZOVNIH USTANOVA IZ DATOTEKE
	/**
	 * Dohvaca obrazovne ustanove iz datoteke.
	 * 
	 * @return
	 */
	public static List<ObrazovnaUstanova> dohvatiObrazovneUstanove( ){
		List<String> buffer= new ArrayList<>();
		List<ObrazovnaUstanova> obrazovneUstanove= new ArrayList<>();
		
		List<Profesor> profesor = dohvatiProfesore();
		List<Student> student = dohvatiStudente();
		List<Predmet> predmet = dohvatiPredmete();
		List<Ispit> ispit  = dohvatiIspite();
		
		try (BufferedReader br = Files.newBufferedReader(Paths.get(Datoteke.Obrazovne_Ustanove.getDat()))) {
			
			buffer=br.lines().map(String::toString).collect(Collectors.toList());
			
			///UPISIVANJE OBRAZOVNIH USTANOVA U LISTU
			for(int i=0; i<buffer.size(); i=i+7) {
				
				List<Integer> predmetId = splitString(buffer.get(i+3).split(" "));
				List<Integer> profesorId = splitString(buffer.get(i+4).split(" "));
				List<Integer> studentId = splitString(buffer.get(i+5).split(" "));
				List<Integer> ispitiUstanoveId = splitString(buffer.get(i+6).split(" "));
				
				List<Predmet> predmeti = new ArrayList<>();
				List<Profesor> profesori = new ArrayList<>();
				List<Student> studenti = new ArrayList<>();
				List<Ispit> ispiti = new ArrayList<>();
				
				predmeti = predmet.stream().filter( elemA -> predmetId.stream().anyMatch( elemB -> elemB == elemA.getId() )).collect(Collectors.toList());
				profesori = profesor.stream().filter( elemA -> profesorId.stream().anyMatch( elemB -> elemB == elemA.getId() )).collect(Collectors.toList());
				studenti = student.stream().filter( elemA -> studentId.stream().anyMatch( elemB -> elemB == elemA.getId() )).collect(Collectors.toList());
				ispiti = ispit.stream().filter( elemA -> ispitiUstanoveId.stream().anyMatch( elemB -> elemB == elemA.getId() )).collect(Collectors.toList());
				
				if( Integer.parseInt(buffer.get(i+1)) == Ustanova.FakultetRacunarstva.getUstanova()) {
					obrazovneUstanove.add(new FakultetRacunarstva(Long.parseLong(buffer.get(i)), buffer.get(i+2), predmeti, profesori, studenti, ispiti, predmetId, profesorId, studentId, ispitiUstanoveId));
				}else if( Integer.parseInt(buffer.get(i+1)) == Ustanova.VeleucilisteJave.getUstanova()){
					obrazovneUstanove.add(new VeleucilisteJave(Long.parseLong(buffer.get(i)), buffer.get(i+2), predmeti, profesori, studenti, ispiti, predmetId, profesorId, studentId, ispitiUstanoveId));
				}
			}
				
		} catch (IOException e) {
			logger.info("Nije moguce ucitati datoteku.");
			System.out.println("Nije moguce ucitati datoteku obrazovnih ustanova ERROR!");
			System.exit(1);
		}	
			
		return obrazovneUstanove;
	}
	
	///CITANJE ISPITA IZ DATOTEKE
	/**
	 * 
	 * Dohvaca ispite iz datoteke.
	 * 
	 * @return lista procitanih ispita
	 */
	public static List<Ispit> dohvatiIspite(){
		List<String> buffer= new ArrayList<>();
		List<Ispit> ispiti= new ArrayList<>();
		
		List<Predmet> predmeti = dohvatiPredmete();
		List<Student> studenti = dohvatiStudente();
				
		try (BufferedReader br = Files.newBufferedReader(Paths.get(Datoteke.Ispiti.getDat()))) {
		
		
			buffer=br.lines().map(String::toString).collect(Collectors.toList());
			
			///UPISIVANJE ISPITA U LISTU
			for(int i=0; i<buffer.size()-1; i=i+5) {
				int idPr = Integer.parseInt(buffer.get(i+2));
				int idSt = Integer.parseInt(buffer.get(i+1));
				
				Predmet predmetIspita = predmeti.stream().filter( a -> a.getId()== idPr).findFirst().get();
				Student studentIspita = studenti.stream().filter( a -> a.getId()== idSt).findFirst().get();
				
				ispiti.add( new Ispit( Long.parseLong(buffer.get(i)), predmetIspita, studentIspita, Integer.parseInt(buffer.get(i+3)), LocalDateTime.parse(buffer.get(i+4), DateTimeFormatter.ofPattern(DATUM_ISPIT))));
			}
					
			} catch (IOException e) {
				logger.info("Nije moguce ucitati datoteku.");
				System.out.println("Nije moguce ucitati datoteku ispita ERROR!");
				System.exit(1);
			}
	
			return ispiti;
	}
	
	///CITANJE PREDMETA IZ DATOTEKE
	/**
	 * Dohvaca studente iz datoteke.
	 * 
	 * @return
	 */
	public static List<Predmet> dohvatiPredmete(){
		
		List<Profesor> profesori = dohvatiProfesore();
		List<Student> studenti = dohvatiStudente();
		List<String> buffer= new ArrayList<>();
		List<Predmet> predmeti= new ArrayList<>();
		
		try (BufferedReader br = Files.newBufferedReader(Paths.get(Datoteke.Predmeti.getDat()))) {
				
		buffer=br.lines().map(String::toString).collect(Collectors.toList());
				
		///UPISIVANJE PREDMETA U LISTU
		for(int i=0; i<buffer.size()-1; i=i+6) {
			
			int nositeljId = Integer.parseInt(buffer.get(i+4));
			Profesor nositelj = profesori.stream().filter( a-> a.getId() == nositeljId ).findAny().get();
					
			predmeti.add(new Predmet( Long.parseLong( buffer.get(i)), buffer.get(i+1), buffer.get(i+2), Integer.parseInt(buffer.get(i+3)), nositelj ));
			
			
			String[] studentiId = buffer.get(i+5).split(" ");
			if(buffer.get(i+5) == " ")continue;
			
			for(String a : studentiId) {
				
				try {
					predmeti.get(predmeti.size()-1).setStudenti(studenti.stream().filter( elem -> elem.getId() == Integer.parseInt(a)).findFirst().get());
				}catch(NoSuchElementException e) {
					logger.info("Nije pronaden trazeni student.");
				}
			}
			
		}
						
		} catch (IOException e) {
			logger.info("Nije moguce ucitati datoteku.");
			System.out.println("Nije moguce ucitati datoteku predmeta ERROR!");
			System.exit(1);
		}
			
		return predmeti;
	} 
	
	///CITANJE SUTDENTA IZ DATOTEKE
	/**
	 * Dohvaca studente iz datoteke.
	 * 
	 * @return lista procitanih studenata
	 */
	public static List<Student> dohvatiStudente(){
		List<String> buffer= new ArrayList<>();
		List<Student> studenti= new ArrayList<>();
		
		
		try (BufferedReader br = Files.newBufferedReader(Paths.get(Datoteke.Studenti.getDat()))) {
							
		buffer=br.lines().map(String::toString).collect(Collectors.toList());
					
		///UPISIVANJE STUDENTA U LISTU 
		for(int i=0; i<buffer.size()-1; i=i+5) {
			studenti.add(new Student( Long.parseLong( buffer.get(i)), buffer.get(i+1), buffer.get(i+2), buffer.get(i+3), LocalDate.parse(buffer.get(i+4), DateTimeFormatter.ofPattern(DATUM)) ) );
		}
							
		} catch (IOException e) {
			logger.info("Nije moguce ucitati datoteku.");
			System.out.println("Nije moguce ucitati datoteku studenata ERROR!");
			System.exit(1);
		}
		
		return studenti;
	}
	
	///CITANJE PROFESORA IZ DATOTEKE
	/**
	 * Dohvaca profesore iz datoteke.
	 * 
	 * @return lista procitanih profesora
	 */
	public static List<Profesor> dohvatiProfesore(){
		List<String> buffer= new ArrayList<>();
		List<Profesor> profesori= new ArrayList<>();
		
		
		try (Stream<String> stream = Files.lines(Paths.get(Datoteke.Profesori.getDat()))) {
					
			buffer = stream.map(String::toString).collect(Collectors.toList());
					
			///UPISIVANJE PROFESORA U LISTU
			for(int i=0; i<buffer.size()-1; i=i+5) {
				profesori.add(new Profesor( Long.parseLong( buffer.get(i)),buffer.get(i+1), buffer.get(i+2), buffer.get(i+3), buffer.get(i+4) ) );
			}
						

		} catch (IOException e) {
			logger.info("Nije moguce ucitati datoteku.");
			System.out.println("Nije moguce ucitati datoteku profesora ERROR!");
			System.exit(1);
		}
				
			return profesori;
	}

}
