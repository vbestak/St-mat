package hr.java.vjezbe;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.BorderPane;

public class IzbornikController {
	
	@FXML
	public  void prikaziPretraguProfesora() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("Profesor.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		} 
	
	@FXML
	public void prikaziPretraguStudenta() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("Student.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		} 
	
	@FXML
	public void prikaziPretraguPredmeta() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("Predmet.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		} 
	
	@FXML
	public void prikaziPretraguIspita() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("Ispit.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		} 
	
	@FXML
	public void prikaziUnosProfesora() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("ProfesorUnos.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		}
	
	@FXML
	public void prikaziUnosStudenta() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("StudentUnos.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		}
	
	@FXML
	public void prikaziUnosPredmeta() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("PredmetUnos.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		}
	
	@FXML
	public void prikaziUnosIspita() {  
		BorderPane root; 
		try { 
			root = (BorderPane)FXMLLoader.load( getClass().getResource("IspitUnos.fxml")); 
			Main.setMainPage(root);   
			} catch (IOException e) {
				e.printStackTrace();  
				} 
		} 
	
}
