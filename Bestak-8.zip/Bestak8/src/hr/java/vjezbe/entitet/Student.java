package hr.java.vjezbe.entitet;

import java.time.LocalDate;

/**
 * Predstavlja studenta koji nasljeduje osobu i ima jmbag i datum rodjenja
 * 
 * @author ValentinoBestak
 *
 */
/**
 * @author ValentinoBestak
 *
 */
public class Student extends Osoba {

	/**
	 * 
	 */
	private static final long serialVersionUID = 290521554669243641L;
	private String jmbag;
	private LocalDate datumRodjenja;
	
	
	/**
	 * Inicijalizira podatke studenta i osobe
	 * 
	 * @param ime ime studenta
	 * @param prezime prezime studenta
	 * @param jmbag jmbag studenta
	 * @param datumRodjenja datum rodjenja studenta
	 */
	public Student (long id, String ime, String prezime, String jmbag, LocalDate datumRodjenja) {
		super(id, ime, prezime);
		this.jmbag=jmbag;
		this.datumRodjenja=datumRodjenja;
	}



	/**
	 * getter metoda za jmbag studenta
	 * 
	 * @return jmbag studenta
	 */
	public String getJmbag() {
		return jmbag;
	}


	/**
	 * setter metoda za jmbag studenta
	 * 
	 * @param jmbag jmbag studenta
	 */
	public void setJmbag(String jmbag) {
		this.jmbag = jmbag;
	}


	/**
	 * getter metoda za datum rodjenja studenta
	 * 
	 * @return datum rodjenja studenta
	 */
	public LocalDate getDatumRodjenja() {
		return datumRodjenja;
	}


	/**
	 * setter metoda za datum rodjenja studenta
	 * 
	 * @param datumRodjenja datum rodjenja studenta
	 */
	public void setDatumRodjenja(LocalDate datumRodjenja) {
		this.datumRodjenja = datumRodjenja;
	}

	@Override
	public String toString() {
		return this.getIme() + " " + this.getPrezime() + " JMBAG: " + this.getJmbag();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((datumRodjenja == null) ? 0 : datumRodjenja.hashCode());
		result = prime * result + ((jmbag == null) ? 0 : jmbag.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (datumRodjenja == null) {
			if (other.datumRodjenja != null)
				return false;
		} else if (!datumRodjenja.equals(other.datumRodjenja))
			return false;
		if (jmbag == null) {
			if (other.jmbag != null)
				return false;
		} else if (!jmbag.equals(other.jmbag))
			return false;
		return true;
	}
	
	
	
}
