package hr.java.vjezbe.entitet;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import hr.java.vjezbe.iznimke.NemoguceOdreditiProsjekStudentaException;

/**
 * Predstavlja visokoskolske ustanove, te omogucava racunanje prosjeka polaznika u istim.
 * 
 * @author ValentinoBestak
 *
 */
public interface Visokoskolska {
	final int NEGATIVNA_OCJENA= 1;
	
	
	/**
	 * Racuna konacnu ocjenu studija za studenta.
	 * 
	 * @param ispit lista ispita studenta za kojega racunamo prosjek
	 * @param pismeniZavrsnogRada ocjena pismenog dijela ispita zavrsnog rada
	 * @param obranaZavrsnogRada ocjena obrane zavrsnog rada
	 * @return vraca konacnu ocjenu studija za studenta
	 */
	BigDecimal izracunajKonacnuOcjenuStudijaZaStudenta(List<Ispit> ispit, int pismeniZavrsnogRada, int obranaZavrsnogRada );
	
	/**
	 * Racuna prosjek ocjena na ispitima. U slucaju negativne ocjene na nekom ispitu baca iznimku.
	 * 
	 * @param ispit polje ispita za koje se racuna prosjek ocjena 
	 * @return vraca prosjek ocjena
	 * @throws NemoguceOdreditiProsjekStudentaException iznimka u slucaju negativne ocjene na ispitu, odnosno u slucaju nemogucnosti racunanja prosjeka ocjene
	 */
	default BigDecimal odrediProsjekOcjenaNaIspitima(List<Ispit> ispit) throws NemoguceOdreditiProsjekStudentaException {
			
		BigDecimal prosjek= new BigDecimal(0);
		int k=0;
		
		
		for(int i=0; i< ispit.size(); i++) {
	
			if(ispit.get(i).getOcjena() == 1) {
				throw  new NemoguceOdreditiProsjekStudentaException("Nemoguce odrediti prosjek na ispitima.");
			}
			
			prosjek = prosjek.add(new BigDecimal(ispit.get(i).getOcjena()));
			k+=1;
		}
		
		if(k==0)
			return new BigDecimal(0);
	
		return prosjek.divide(new BigDecimal(k));
	}
	
	/*private Ispit[] filtrirajPolozeneIspite(Ispit[] ispit) {
		
		int k=0;
		
		for (int i=0; i< (Array.getLength(ispit)); i++) {
			if (ispit[i].getOcjena() != NEGATIVNA_OCJENA ) k++;
		}
		
		Ispit[] ispitPolozeni = new Ispit[k];
		
		/// refresh
		k=0;
		
		for(int i=0; i< Array.getLength(ispit); i++) {
			if(ispit[i].getOcjena() != 1) {
				ispitPolozeni[k] = ispit[i];
				k++;
			}
		}
		
		return ispitPolozeni;
	}*/
	
	/**
	 * Filtriranje ispita po studentu.
	 * 
	 * @param ispit lista ispita koje se filtrira
	 * @param student student po kojemu filtriramo ispite
	 * @return vraca filtrirano polje ispita
	 */
	default List<Ispit> filtrirajIspitePoStudentu (List<Ispit> ispit, Student student) {
		
		List<Ispit> ispitiStudenta = ispit.stream().filter( (Ispit s) ->(student.equals(s.getStudent()))).collect(Collectors.toList());
		
		
		/*for(int i=0; i< ispit.size(); i++) {
			if ((ispit.get(i).getStudent()).equals(student)) {
				ispitiStudenta.add(ispit.get(i));
			}
		}*/
		
		return ispitiStudenta;
	}
	
}