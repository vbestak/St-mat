package hr.java.vjezbe.entitet;

import java.util.ArrayList;
import java.util.List;

/**
 * Predstavlja sveucilisnu ustanovu koja nasljeduje obrazovnustanovu
 * 
 * @author ValentinoBestak
 *
 * @param <T> tip liste
 */
public class Sveuciliste<T extends ObrazovnaUstanova> extends Entitet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6205223280069931893L;
	private List<T> ustanova;
	
	
	/**
	 * Konstruktor klase
	 * 
	 * @param nazivUstanove naziv obrazovne ustanove
	 * @param predmet lista predmeta ustanove
	 * @param profesor lista profesora ustanove	
	 * @param student lista stidenta ustanove
	 * @param ispit lista ispita ustanove
	 */
	public Sveuciliste(long id) {
		super(id);
		ustanova = new ArrayList<>();
	}

	
	/**
	 * Dodaje ustanovu u listu.
	 * 
	 * @param ustanova koju dodajemo u listu
	 */
	public void dodajObrazovnuUstanovu(T ustanova) {
		this.ustanova.add(ustanova);
	}
	
	/**
	 * Dohvaca ustanovu.
	 * 
	 * @param index ustanove koju zelimo
	 * @return ustanova
	 */
	public T dohvatiObrazovnuUstanovu(int index) {
		return ustanova.get(index);
	}
	
	
	/**
	 * Vraca listu ustanova.
	 * 
	 * @return listu obrazovnih ustanova
	 */
	public List<T> getUstanove() {
		return ustanova;
	}
	
	
}
