package hr.java.vjezbe.entitet;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import hr.java.vjezbe.iznimke.NemoguceOdreditiProsjekStudentaException;
import hr.java.vjezbe.iznimke.PostojiViseNajmladjihStudenataException;

/**
 * Predstavlja klasu fakulteta racunarstva koje nasljeduje obrazovnu ustanovu i implementira sucelje diplomski.
 * @see ObrazovnaUstanova
 * @see Diplomski
 * @author ValentinoBestak
 *
 */
public class FakultetRacunarstva extends ObrazovnaUstanova implements Diplomski {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3194761136572517841L;
	private final int ODLICAN= 5;
	private static Logger logger = LoggerFactory.getLogger(FakultetRacunarstva.class);;
	
	/**
	 * Inicijalizira podatke obrazovne ustanove
	 * 
	 * @param nazivUstanove naziv obrazovne ustanove
	 * @param predmet lista predmeta
	 * @param profesor lista profesora
	 * @param student lista studenta
	 * @param ispit lista ispita
	 */
	public FakultetRacunarstva(long id, String nazivUstanove, List<Predmet> predmet, List<Profesor> profesor, List<Student> student, List<Ispit> ispit,
			List<Integer> predmetiUstanove, List<Integer> profesoriUstanove, List<Integer> studentiUstanove, List<Integer> ispitiUstanove)  {
		
		super(id, nazivUstanove, predmet, profesor, student, ispit, predmetiUstanove, profesoriUstanove, studentiUstanove, ispitiUstanove);
	}

	/**
	 * @see hr.java.vjezbe.entitet.Visokoskolska#izracunajKonacnuOcjenuStudijaZaStudenta(hr.java.vjezbe.entitet.Ispit[], int, int)
	 */
	@Override
	public BigDecimal izracunajKonacnuOcjenuStudijaZaStudenta(List<Ispit> ispit, int pismeniDiplomskogRada, int obranaDiplomskogRada) {
		BigDecimal prosjek= new BigDecimal(0);
		
		try {
		prosjek = odrediProsjekOcjenaNaIspitima(ispit);
		}catch(NemoguceOdreditiProsjekStudentaException e) {
			System.out.println("Student " + ispit.get(0).getStudent().getIme() + " "+ ispit.get(0).getStudent().getPrezime() + " zbog negativne ocjene na jednom od ispita ima prosjek nedovoljan (1)!");
			logger.error("Student ima 1 na nekom ispitnom roku.");
		}
		prosjek= prosjek.multiply(new BigDecimal(3));
		prosjek= prosjek.add(new BigDecimal(pismeniDiplomskogRada+obranaDiplomskogRada));
		prosjek= prosjek.divide(new BigDecimal(5));
		
		prosjek = prosjek.setScale(0, RoundingMode.HALF_UP);
		
		///kona�na ocjena = (3 * prosjek ocjena studenta + ocjena diplomskog rada + ocjena obrane diplomskog rada) / 5 
		return prosjek;
	}

	/**
	 * @see hr.java.vjezbe.entitet.Diplomski#odrediStudentaZaRektorovuNagradu()
	 */
	@Override
	public Student odrediStudentaZaRektorovuNagradu() throws PostojiViseNajmladjihStudenataException {
		
		BigDecimal najUspijesniji= new BigDecimal(0);
		int najboljiStudent=0,k=0;
		Integer istiDatum[]= new Integer[5];
		
		for(int i=0; i< student.size(); i++) {
			BigDecimal usporedba= new BigDecimal(0);
			
			try {
			usporedba=odrediProsjekOcjenaNaIspitima(filtrirajIspitePoStudentu(ispit, student.get(i)));
			}catch(NemoguceOdreditiProsjekStudentaException e) {
				continue;
			}
			if(usporedba.compareTo(najUspijesniji)==1) {
				najUspijesniji = usporedba;
				najboljiStudent = i;
				k=0;
			}
			else if( usporedba.compareTo(najUspijesniji)==0) {
				if(student.get(najboljiStudent).getDatumRodjenja().isBefore(student.get(i).getDatumRodjenja())) {
					najUspijesniji = usporedba;
					najboljiStudent = i;
					k=0;
				}else if (student.get(najboljiStudent).getDatumRodjenja().isEqual(student.get(i).getDatumRodjenja())){
					istiDatum[k]=i;
					k++;
				}
			}
		}
		
		if(k!=0)
		if(student.get(najboljiStudent).getDatumRodjenja().isEqual(student.get(istiDatum[0]).getDatumRodjenja()))
			if(student.get(najboljiStudent).equals(student.get(istiDatum[0]))) {
				
			}else {
				throw new PostojiViseNajmladjihStudenataException(student.get(najboljiStudent).getIme() + " " + student.get(najboljiStudent).getPrezime() + ", " + student.get(istiDatum[0]).getIme() + " " + student.get(istiDatum[0]).getPrezime());
			}
				
		return student.get(najboljiStudent);
	}

	/**
	 * @see hr.java.vjezbe.entitet.ObrazovnaUstanova#odrediNajuspjesnijegStudentaNaGodini(int)
	 */
	@Override
	public Student odrediNajuspjesnijegStudentaNaGodini(int godina) {
		
		int najUspijesniji= 0;
		int najboljiStudent=0;
		
		for(int i=0; i< student.size(); i++) {
			int usporedba= 0;
			
		    List<Ispit> ispitiStudenta = filtrirajIspitePoStudentu(ispit, student.get(i));
			
		     ///provjera da li su ispiti pisani ove godine
		    if(ispitiStudenta.isEmpty()) {continue;}
		    //if(ispitiStudenta.get(0).getDatumIVrijeme().getYear() != godina) {continue;}

		    for(int j=0; j< ispitiStudenta.size(); j++) {
		    	if(ispitiStudenta.get(j).getOcjena() == ODLICAN) {
		    		usporedba +=1;
		    	}
		    }
		    
			if(usporedba > najUspijesniji) {
				najUspijesniji = usporedba;
				najboljiStudent = i;
			}
		}
		
		return student.get(najboljiStudent);
	}

}
