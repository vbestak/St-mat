package hr.java.vjezbe.entitet;

import java.util.List;

/**
 * Predstavlja Obrazovnu ustanovu koja sadrzi naziv, predmete, profesore, studente i ispite.
 * 
 * @author ValentinoBestak
 *
 */
/**
 * @author ValentinoBestak
 *
 */
public abstract class ObrazovnaUstanova extends Entitet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7562357259369361174L;
	
	protected String nazivUstanove;
	protected List<Predmet> predmet;
	protected List<Profesor> profesor;
	protected List<Student> student;
	protected List<Ispit> ispit;
//	private List<Integer> predmetiUstanove;
//	private List<Integer> profesoriUstanove;
//	private List<Integer> studentiUstanove;
//	private List<Integer> ispitiUstanove;
	
	
	/**
	 * Inicijalizira podatke obrazovne ustanove.
	 * 
	 * @param nazivUstanove naziv obrazovne ustanove
	 * @param predmet lista predmeta
	 * @param profesor lista profesora
	 * @param student lista studenata
	 * @param ispit lista ispita
	 */
	public ObrazovnaUstanova(long id, String nazivUstanove,List<Predmet> predmeti, List<Profesor> profesori, List<Student> studenti, List<Ispit> ispiti,
			List<Integer> predmetiUstanove, List<Integer> profesoriUstanove, List<Integer> studentiUstanove, List<Integer> ispitiUstanove) {
		super(id);
		this.nazivUstanove = nazivUstanove;
		this.predmet = predmeti;
		this.profesor = profesori;
		this.student = studenti;
		this.ispit = ispiti;
//		this.predmetiUstanove=predmetiUstanove;
//		this.profesoriUstanove=profesoriUstanove;
//		this.studentiUstanove=studentiUstanove;
//		this.ispitiUstanove=ispitiUstanove;	
		
	}


	/**
	 * Odreduje najuspijesnijeg studenta odredene godine.
	 * 
	 * @param godina godina u kojoj se odreduje najuspijesniji student
	 * @return vraca najuspijesnijeg studenta
	 */
	public abstract Student odrediNajuspjesnijegStudentaNaGodini(int godina);
	
	
	/**
	 * getter metoda za nazivUstanove
	 * 
	 * @return naziv stanove
	 */
	public String getNazivUstanove() {
		return nazivUstanove;
	}


	/**
	 * setter metoda za nazivUstanove
	 * 
	 * @param nazivUstanove
	 */
	public void setNazivUstanove(String nazivUstanove) {
		this.nazivUstanove = nazivUstanove;
	}


	/**
	 * getter metoda predmeta u obrazovnoj ustanovi
	 * 
	 * @return listu predmeta
	 */
	public List<Predmet> getPredmet() {
		return predmet;
	}


	/**
	 * setter metoda za listu predmeta
	 * 
	 * @param predmet lista predmeta
	 */
	public void setPredmet(List<Predmet> predmet) {
		this.predmet = predmet;
	}


	/**
	 * getter metoda za profesore
	 * 
	 * @return lista profesora
	 */
	public List<Profesor> getProfesor() {
		return profesor;
	}


	/**
	 * setter metoda za profesore
	 * 
	 * @param profesor lista profesora
	 */
	public void setProfesor(List<Profesor> profesor) {
		this.profesor = profesor;
	}


	/**
	 * getter metoda za studente
	 * 
	 * @return lista studenta
	 */
	public List<Student> getStudent() {
		return student;
	}


	/**
	 * setter metoda za studenta
	 * 
	 * @param student lista studenta
	 */
	public void setStudent(List<Student> student) {
		this.student = student;
	}


	/**
	 * getter metoda za ispite
	 * 
	 * @return lista ispita
	 */
	public List<Ispit> getIspit() {
		return ispit;
	}


	/**
	 * setter metoda za ispite
	 * 
	 * @param ispit lista ispita
	 */
	public void setIspit(List<Ispit> ispit) {
		this.ispit = ispit;
	}
	
	@Override
	public String toString() {
		return nazivUstanove;
	}
	
	
}
