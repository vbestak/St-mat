package hr.java.vjezbe.entitet;

import java.io.Serializable;

/**
 * Predstavlja entitet koji ima svoj identifikacijski broj, te kojega je moguce serijalizirati.
 * 
 * @author ValentinoBestak
 *
 */
public abstract class Entitet implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8645209795747170807L;
	private long id;

	
	
	/**
	 * Konstruktor koji prima id objekta.
	 * 
	 * @param id
	 */
	public Entitet(long id) {
		super();
		this.id = id;
	}

	/**
	 * Getter metoda za dohvacanje id-a nekog objekta.
	 * 
	 * @return id objekta
	 */
	public long getId() {
		return id;
	}

	/**
	 * Setter metoda za mijenjanje id-a nekog objekta.
	 * 
	 * @param id novi id kojega zelimo postaviti
	 */
	public void setId(long id) {
		this.id = id;
	}
	
	
}
