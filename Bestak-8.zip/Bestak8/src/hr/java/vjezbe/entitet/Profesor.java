package hr.java.vjezbe.entitet;

/**
 * Predstavlja profesora koji koji nasljeduje profesora i sadrzi sifru i titulu.
 * 
 * @author ValentinoBestak
 *
 */
public class Profesor extends Osoba {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5627185050531011730L;
	private String sifra;
	private String titula;
	
	
	/**
	 * Inicijalizira podatke profesora i osobe.
	 * 
	 * @param sifra sifra profesora
	 * @param ime ime profesora
	 * @param prezime prezime profesora
	 * @param titula titula profesora
	 */
	public Profesor(long id, String sifra, String ime, String prezime, String titula) {
		super(id, ime, prezime);
		this.sifra = new String(sifra);
		this.titula = new String(titula);
	}


	/**
	 * getter metoda za sifru
	 * 
	 * @return sifra profesora
	 */
	public String getSifra() {
		return sifra;
	}


	/**
	 * setter metoda za sifru
	 * 
	 * @param sifra sifra profesora
	 */
	public void setSifra(String sifra) {
		this.sifra = sifra;
	}


	/**
	 * getter metoda za titulu profesora
	 * 
	 * @return titula profesora
	 */
	public String getTitula() {
		return titula;
	}


	/**
	 * setter metoda za titulu profesora
	 * 
	 * @param titula titula profesora
	 */
	public void setTitula(String titula) {
		this.titula = titula;
	}
	
	@Override
	public String toString() {
		return this.getSifra() + " " + this.getIme() + " " + this.getPrezime();
	} 
	
}
