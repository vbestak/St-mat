package hr.java.vjezbe.entitet;

import java.time.LocalDateTime;

/**
 * Predstavlja ispit koji sadrzi predmet, studenta ocjenu i vrijeme ispita.
 * 
 * @author ValentinoBestak
 *
 */
public class Ispit extends Entitet {

		/**
	 * 
	 */
	private static final long serialVersionUID = 840470998725509103L;
		private Predmet predmet;
		private Student student;
		private int ocjena;
		private LocalDateTime datumIVrijeme;
		
		/**
		 * Inicijalizira podatke ispita.
		 * 
		 * @param predmet predstavlja predmet ispita
		 * @param student predstavlja studenta koji polazi ispit	
		 * @param ocjena predstavlja ocjenu studenta na ispitu
		 * @param datumIVrijeme predstavlja vrijeme pisanja ispita
		 */
		public Ispit(long id, Predmet predmet, Student student, int ocjena, LocalDateTime datumIVrijeme) {
			super(id);
			this.predmet = predmet;
			this.student = student;
			this.ocjena = ocjena;
			this.datumIVrijeme = datumIVrijeme;
		}

		/**
		 * getter metoda za predmet
		 * 
		 * @return predmet
		 */
		public Predmet getPredmet() {
			return predmet;
		}

		/**
		 * setter metoda za predmet
		 * 
		 * @param predmet Premdet koji postavljamo
		 */
		public void setPredmet(Predmet predmet) {
			this.predmet = predmet;
		}

		/**
		 * getter metoda za studenta
		 * 
		 * @return student koji polaze ispit
		 */
		public Student getStudent() {
			return student;
		}

		/**
		 * setter metoda za studenta
		 * 
		 * @param student Student kojeg postavljamo
		 */
		public void setStudent(Student student) {
			this.student = student;
		}

		/**
		 * getter metoda za ocjenu
		 * 
		 * @return ocjena studenta na ispitu
		 */
		public int getOcjena() {
			return ocjena;
		}

		/**
		 * setter metoda za ocjenu
		 * 
		 * @param ocjena int koji predstavlja ocjenu
		 */
		public void setOcjena(int ocjena) {
			this.ocjena = ocjena;
		}

		/**
		 * getter metoda za datum i vrijeme
		 * 
		 * @return datum i vrijeme pisanog ispita
		 */
		public LocalDateTime getDatumIVrijeme() {
			return datumIVrijeme;
		}

		/**
		 * setter metoda za datum i vrijeme
		 * 
		 * @param datumIVrijeme LocalDateTime koji predstavlja datum
		 */
		public void setDatumIVrijeme(LocalDateTime datumIVrijeme) {
			this.datumIVrijeme = datumIVrijeme;
		}
		
		public String getNaziv() {
			return predmet.getNaziv();
		}
		
		public String getIme() {
			return student.getIme();
		}
		
		public String getPrezime() {
			return student.getPrezime();
		}
		
		@Override
		public String toString() {
			return "Student "+ this.getStudent().getIme() + " "+ this.getStudent().getPrezime() + 
					" je ostvario ocjenu 'izvrstan' na predmetu "+ "'"+ this.getPredmet().getNaziv()+"'." ;
		}
}
