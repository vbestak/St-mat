package hr.java.vjezbe.entitet;
import hr.java.vjezbe.iznimke.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Predstavlja veleuciliste jave koje nasljeduje obrazovnu ustanovu i implementira sucelje visokoskolska.
 * @see ObrazovnaUstanova
 * @see Visokoskolska
 * @author ValentinoBestak
 *
 */
public class VeleucilisteJave extends ObrazovnaUstanova implements Visokoskolska {
	/**
	 * 
	 */
	private static final long serialVersionUID = 382314206055505260L;
	private static Logger logger = LoggerFactory.getLogger(VeleucilisteJave.class);;
	
	/**
	 * Inicijalizira podatke obrazovne ustanove.
	 * 
	 * @param nazivUstanove naziv obrazovne ustanove
	 * @param predmet lista predmeta
	 * @param profesor lista profesora
	 * @param student lista studenta
	 * @param ispit lista ispita
	 */
	public VeleucilisteJave(long id, String nazivUstanove, List<Predmet> predmet, List<Profesor> profesor, List<Student> student, List<Ispit> ispit,
				List<Integer> predmetiUstanove, List<Integer> profesoriUstanove, List<Integer> studentiUstanove, List<Integer> ispitiUstanove)  {
		
		super(id, nazivUstanove, predmet, profesor, student, ispit, predmetiUstanove, profesoriUstanove, studentiUstanove, ispitiUstanove);
	}

	/**
	 * @see hr.java.vjezbe.entitet.Visokoskolska#izracunajKonacnuOcjenuStudijaZaStudenta(hr.java.vjezbe.entitet.Ispit[], int, int)
	 */
	@Override
	public BigDecimal izracunajKonacnuOcjenuStudijaZaStudenta(List<Ispit> ispit, int pismeniZavrsnogRada, int obranaZavrsnogRada) {
		BigDecimal prosjek= new BigDecimal(0);
		
		try {
		prosjek = odrediProsjekOcjenaNaIspitima(ispit);
		
		prosjek= prosjek.multiply(new BigDecimal(2));
		prosjek= prosjek.add(new BigDecimal(pismeniZavrsnogRada+obranaZavrsnogRada));
		prosjek= prosjek.divide(new BigDecimal(4));
		
		prosjek = prosjek.setScale(0, RoundingMode.HALF_UP);
		}catch(NemoguceOdreditiProsjekStudentaException e) {
			System.out.println("Student " + ispit.get(0).getStudent().getIme() + " "+ ispit.get(0).getStudent().getPrezime() + " zbog negativne ocjene na jednom od ispita ima prosjek nedovoljan (1)!");
			logger.error("Student ima 1 na nekom ispitnom roku.");
		}
		
		
		///kona�na ocjena = (2 * prosjek ocjena studenta + ocjena zavr�nog rada + ocjena obrane zavr�nog rada) / 4
		return prosjek;
	}

	/**
	 * @see hr.java.vjezbe.entitet.ObrazovnaUstanova#odrediNajuspjesnijegStudentaNaGodini(int)
	 */
	@Override
	public Student odrediNajuspjesnijegStudentaNaGodini(int godina) {
		BigDecimal najUspijesniji= new BigDecimal(0);
		int najboljiStudent=0;
		
		for(int i=0; i< student.size(); i++) {
			BigDecimal usporedba= new BigDecimal(0);
			
			///provjera da li su ispiti pisani ove godine
			if((filtrirajIspitePoStudentu(ispit, student.get(i))).get(0).getDatumIVrijeme().getYear() != godina) {continue;}
			
			try {
			usporedba=odrediProsjekOcjenaNaIspitima(filtrirajIspitePoStudentu(ispit, student.get(i)));
			}catch(NemoguceOdreditiProsjekStudentaException e) {
				continue;
			}
			
			
			if( usporedba.compareTo(najUspijesniji)==0 || usporedba.compareTo(najUspijesniji)==1) {
				najUspijesniji = usporedba;
				najboljiStudent = i;
			}
		}
		
		return student.get(najboljiStudent);
	}

}

