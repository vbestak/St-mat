package hr.java.vjezbe.entitet;

import java.util.*;

/**
 * Predstavlja predmet koji sadrzi sifru, naziv, broj ECTS bodova, nositelja predmeta i studente.
 * 
 * @author ValentinoBestak
 *
 */
public class Predmet extends Entitet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7671776416681912111L;
	private String sifra;
	private String naziv;
	private int brojEctsBodova;
	private Profesor nositelj;
	public Set<Student> studenti = new HashSet<>();
	
	/**
	 * Inicijalizira podatke predmeta.
	 * 
	 * @param sifra string sifra predmeta
	 * @param naziv string naziv predmeta
	 * @param brojEctsBodova int ects bodovi
	 * @param nositelj Profesor koji je nositelj predmeta
	 * @param velicina broj studenata na predmetu
	 */
	public Predmet(long id, String sifra, String naziv, int brojEctsBodova, Profesor nositelj) {
		super(id);
		this.sifra = sifra;
		this.naziv = naziv;
		this.brojEctsBodova = brojEctsBodova;
		this.nositelj = nositelj;
	}

	/**
	 * getter metoda za sifru
	 * 
	 * @return sifra predmeta
	 */
	public String getSifra() {
		return sifra;
	}

	/**
	 * setter metoda za sifru
	 * 
	 * @param sifra string koji predstavlja sifru
	 */
	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	/**
	 * getter metpda za naziv
	 * 
	 * @return naziv predmeta
	 */
	public String getNaziv() {
		return naziv;
	}

	/**
	 * setter metoda za naziv predmeta
	 * 
	 * @param naziv string koji predstavlja naziv predmeta
	 */
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	/**
	 * getter metoda za broj ets bodova
	 * 
	 * @return broj ects bodova predmeta
	 */
	public int getBrojEctsBodova() {
		return brojEctsBodova;
	}

	/**
	 * setter metoda za broj ects bodova
	 * 
	 * @param brojEctsBodova kolicina ects bodova
	 */
	public void setBrojEctsBodova(int brojEctsBodova) {
		this.brojEctsBodova = brojEctsBodova;
	}

	/**
	 *  getter metoda za nositekja predmeta
	 * 
	 * @return profesor odnosno nositelj predmeta
	 */
	public Profesor getNositelj() {
		return nositelj;
	}

	/**
	 * setter metoda za nositelja predmeta
	 * 
	 * @param nositelj Profesor nositelj predmeta
	 */
	public void setNositelj(Profesor nositelj) {
		this.nositelj = nositelj;
	}

	/**
	 * getter metoda za studente
	 * 
	 * @return lista studenta
	 */
	public Set<Student> getStudenti() {
		return studenti;
	}

	/**
	 * setter metoda za studente
	 * 
	 * @param studenti set studenta
	 */
	public void setStudenti(Set<Student> studenti) {
		this.studenti = studenti;
	}
	
	/**
	 * setter metoda za studente ako dodajemo jednog po jednog
	 * 
	 * @param student student kojeg zelimo dodati u set studenta
	 */
	public void setStudenti(Student student) {
		studenti.add(student);
	}
	
	public String getIme() {
		return nositelj.getIme();
	}
	
	public String getPrezime() {
		return nositelj.getPrezime();
	}
	
	@Override
	public String toString() {
		return this.sifra + " " + this.naziv;
	}
}
