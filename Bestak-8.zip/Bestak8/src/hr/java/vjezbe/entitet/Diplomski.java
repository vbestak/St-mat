package hr.java.vjezbe.entitet;

import hr.java.vjezbe.iznimke.PostojiViseNajmladjihStudenataException;

/**
 * Predstavlja sucelje diplomski koje nasljedjuje Visokoskolska.
 * @see Visokoskolska
 * @author ValentinoBestak
 *
 */
public interface Diplomski extends Visokoskolska {
		
	/**
	 * Odreduje studena za rektorovu nagradu. Racuna prosjeke studenata te vraca najveci. Ako vise studenata ima jednaki prosjek, nagradu osvaja mladji.
	 * 
	 * @return vraca studenta koji osvaja rektorovu nagradu
	 * @throws PostojiViseNajmladjihStudenataException baca iznimku ako postoji vise studenata sa najvecim prosjekom i istim datumom rodjenja
	 */
	Student odrediStudentaZaRektorovuNagradu () throws PostojiViseNajmladjihStudenataException;
}
