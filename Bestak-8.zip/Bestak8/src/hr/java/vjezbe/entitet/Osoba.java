package hr.java.vjezbe.entitet;

/**
 * Predstavlja osobu koja ima ime i prezime
 * 
 * @author ValentinoBestak
 *
 */
public abstract class Osoba extends Entitet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3389685921085549490L;
	private String ime;
	private String prezime;
	
	
	/**
	 * Inicijalizira podatke ime i prezime
	 * 
	 * @param ime ime osobe
	 * @param prezime prezime osobe
	 */
	public Osoba(long id, String ime, String prezime) {
		super(id);
		this.ime = ime;
		this.prezime = prezime;
	}


	/**
	 * getter metoda za ime
	 * 
	 * @return ime ime osobe
	 */
	public String getIme() {
		return ime;
	}


	/**
	 * setter metoda za ime
	 * 
	 * @param ime ime osobe
	 */
	public void setIme(String ime) {
		this.ime = ime;
	}


	/**
	 * getter metoda za prezime
	 * 
	 * @return prezime
	 */
	public String getPrezime() {
		return prezime;
	}


	/**
	 * setter metoda za prezime
	 * 
	 * @param prezime prezime osobe
	 */
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	
	
}
