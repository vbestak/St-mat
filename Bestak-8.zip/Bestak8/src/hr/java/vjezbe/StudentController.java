package hr.java.vjezbe;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import hr.java.vjezbe.entitet.Student;
import hr.java.vjezbe.util.GlavnaDatoteke;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

public class StudentController{
	List<Student> studenti = new ArrayList<>();
	List<Student> filtriraniStudenti = new ArrayList<>();
	ObservableList<Student> list = FXCollections.observableArrayList();
	
	@FXML TextField jmbagTextField;
	@FXML TextField prezimeTextField;
	@FXML TextField imeTextField;
	@FXML DatePicker datumTextField;
	@FXML TableView<Student> table;
	@FXML TableColumn<Student, String> jmbagColumn;
	@FXML TableColumn<Student, String> prezimeColumn;
	@FXML TableColumn<Student, String> imeColumn;
	@FXML TableColumn<Student, String> datumColumn;
	@FXML Button pretragaButton;
	
	@FXML
	private void initialize() {
		
		
		studenti = GlavnaDatoteke.dohvatiStudente();
		jmbagColumn.setCellValueFactory(new PropertyValueFactory<>("jmbag"));
		prezimeColumn.setCellValueFactory(new PropertyValueFactory<>("prezime"));
		imeColumn.setCellValueFactory(new PropertyValueFactory<>("ime"));
		datumColumn.setCellValueFactory(new PropertyValueFactory<>("datumRodjenja"));
		
		list.setAll(studenti);
		table.setItems(list);
		
		datumColumn.setCellValueFactory( 
				new Callback<TableColumn.CellDataFeatures<Student, String>,
				ObservableValue<String>>() { 
					@Override    
					public ObservableValue<String> call(
							TableColumn.CellDataFeatures<Student, String> student) {
						SimpleStringProperty property = new  SimpleStringProperty();
						DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("dd.MM.yyyy."); 
						property.setValue( student.getValue().getDatumRodjenja().format(formatter));   
						return property;   
						} 
				}
		);


	}
	
	@FXML
	private void pretragaButtonAction() {
		filtriraniStudenti.clear();
		filtriraniStudenti.addAll(studenti);
		
		if(jmbagTextField.getText().length()>0) {
			filtriraniStudenti=filtriraniStudenti.stream()
					.filter( a -> a.getJmbag().toLowerCase().contains(jmbagTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(prezimeTextField.getText().length()>0) {
				filtriraniStudenti= filtriraniStudenti.stream()
						.filter( a -> a.getPrezime().toLowerCase().contains(prezimeTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		if(imeTextField.getText().length()>0){
				filtriraniStudenti= filtriraniStudenti.stream()
						.filter( a ->a.getIme().toLowerCase().contains(imeTextField.getText().toLowerCase())).collect(Collectors.toList());
		}
		
		
		if(datumTextField.getValue() != null ) {
				filtriraniStudenti= filtriraniStudenti.stream()
						.filter( a -> a.getDatumRodjenja().isEqual(datumTextField.getValue())).collect(Collectors.toList());
		}
		
		list.setAll(filtriraniStudenti);
		System.out.println("Gumb kliknut");
		
	}
}
